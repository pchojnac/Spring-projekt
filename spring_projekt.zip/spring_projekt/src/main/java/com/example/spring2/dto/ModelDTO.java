package com.example.spring2.dto;

import lombok.Data;

@Data
public class ModelDTO {

    private Long id;
    private String name;
}
