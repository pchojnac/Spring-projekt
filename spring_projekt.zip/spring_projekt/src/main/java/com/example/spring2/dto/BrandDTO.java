package com.example.spring2.dto;

import lombok.Data;

// data transfer object
@Data
public class BrandDTO {

    private Long id;
    private String name;
}
